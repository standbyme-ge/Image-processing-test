function [Y,LP]=ZeroMeanTotal(X)
% ���к�ɫ�Ͱ�ɫ�к����Ӽ��м�ȥ��ֵ

Y = zeros(size(X));

[Z,LP11] = ZeroMean(X(1:2:end,1:2:end,:),'both');
Y(1:2:end,1:2:end,:) = Z;
[Z,LP12] = ZeroMean(X(1:2:end,2:2:end,:),'both');
Y(1:2:end,2:2:end,:) = Z;
[Z,LP21] = ZeroMean(X(2:2:end,1:2:end,:),'both');
Y(2:2:end,1:2:end,:) = Z;
[Z,LP22] = ZeroMean(X(2:2:end,2:2:end,:),'both');
Y(2:2:end,2:2:end,:) = Z;

LP.d11=LP11; LP.d12=LP12; LP.d21=LP21; LP.d22=LP22; 