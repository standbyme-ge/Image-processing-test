%% ������

% ���ȵ���ͼ������3*20��ָ��
% �����׼ƫ��
% �������ο�ģʽ
% ����3�豸��ָ�Ʒֱ��3*30�Ų���
% ��ȡÿ��ͼƬ��������
% ��������������ԡ�



clc,clear

FileList=dir('E:\research\project-9\k_image\*jpg');
[FM,FN] = size(FileList);
%list:  1:50 Android    |    51:100 IPad      |     101:150 IPhone


% 
for Fi=1:20
    imx = strcat('E:\research\project-9\k_image\',FileList(Fi).name);
    Android(Fi).name = imx;
end
for Fi=1:20
    imx = strcat('E:\research\project-9\k_image\',FileList(Fi+50).name);
    Ipad(Fi).name = imx;
end
for Fi=1:20
    imx = strcat('E:\research\project-9\k_image\',FileList(Fi+100).name);
    Iphone(Fi).name = imx;
end
%
%��ȡָ�Ʋ�ת��ҶȻ�
RP1 = getFingerprint(Android);
RP2 = getFingerprint(Ipad);
RP3 = getFingerprint(Iphone);

RP1 = rgb2gray1(RP1);
RP2 = rgb2gray1(RP2);
RP3 = rgb2gray1(RP3);
%
%����ָ�Ƶı�׼ƫ��
sigmaRP1 = std2(RP1);
sigmaRP2 = std2(RP2);
sigmaRP3 = std2(RP3);

%%�������ο�ģʽ-PRNU�Ĺ���
Fingerprint1 = WienerInDFT(RP1,sigmaRP1);
Fingerprint2 = WienerInDFT(RP2,sigmaRP2);
Fingerprint3 = WienerInDFT(RP3,sigmaRP3);

%% ����
[AA,BB,CC]=deal(zeros(30*3,1));


for Fi=21:50

imx = strcat('E:\research\project-9\k_image\',FileList(Fi).name);
Noisex = NoiseExtractFromImage(imx,2);
Noisex = WienerInDFT(Noisex,std2(Noisex));

%��Ѽ����
k=1;nn1=Fi-20+(k-1)*30;
Ix = double(rgb2gray(imread(imx)));
C = crosscorr(Noisex,Ix.*Fingerprint1);
detection = PCE(C);
AA(nn1)=detection.PCE;

k=2;nn2=Fi-20+(k-1)*30;
Ix = double(rgb2gray(imread(imx)));
C = crosscorr(Noisex,Ix.*Fingerprint2);
detection = PCE(C);
AA(nn2)=detection.PCE;

k=3;nn3=Fi-20+(k-1)*30;
Ix = double(rgb2gray(imread(imx)));
C = crosscorr(Noisex,Ix.*Fingerprint3);
detection = PCE(C);
AA(nn3)=detection.PCE;
end

for Fi=71:100

imx = strcat('E:\research\project-9\k_image\',FileList(Fi).name);
Noisex = NoiseExtractFromImage(imx,2);
Noisex = WienerInDFT(Noisex,std2(Noisex));

%��Ѽ����
k=1;nn1=Fi-70+(k-1)*30;
Ix = double(rgb2gray(imread(imx)));
C = crosscorr(Noisex,Ix.*Fingerprint1);
detection = PCE(C);
BB(nn1)=detection.PCE;

k=2;nn2=Fi-70+(k-1)*30;
Ix = double(rgb2gray(imread(imx)));
C = crosscorr(Noisex,Ix.*Fingerprint2);
detection = PCE(C);
BB(nn2)=detection.PCE;

k=3;nn3=Fi-70+(k-1)*30;
Ix = double(rgb2gray(imread(imx)));
C = crosscorr(Noisex,Ix.*Fingerprint3);
detection = PCE(C);
BB(nn3)=detection.PCE;

end

for Fi=121:150

imx = strcat('E:\research\project-9\k_image\',FileList(Fi).name);
Noisex = NoiseExtractFromImage(imx,2);
Noisex = WienerInDFT(Noisex,std2(Noisex));

%��Ѽ����
k=1;nn1=Fi-120+(k-1)*30;
Ix = double(rgb2gray(imread(imx)));
C = crosscorr(Noisex,Ix.*Fingerprint1);
detection = PCE(C);
CC(nn1)=detection.PCE;

k=2;nn2=Fi-120+(k-1)*30;
Ix = double(rgb2gray(imread(imx)));
C = crosscorr(Noisex,Ix.*Fingerprint2);
detection = PCE(C);
CC(nn2)=detection.PCE;

k=3;nn3=Fi-120+(k-1)*30;
Ix = double(rgb2gray(imread(imx)));
C = crosscorr(Noisex,Ix.*Fingerprint3);
detection = PCE(C);
CC(nn3)=detection.PCE;

end

%%
figure
hold on
plot(AA,'b'),plot(BB,'r'),plot(CC,'g'),
xlabel('1:30-Android              31:60-Ipad                61:90-Iphone')
ylabel('�����')