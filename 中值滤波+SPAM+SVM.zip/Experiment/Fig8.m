clc,clear,close all
%Figure.8  3x3 B=64 JEPG 100,90,95

%% 1.main
B=64;
[k, l] = deal(0,1); %ͬʱ��ֵ
Img_targets = zeros(20000,3); %1w*3:med, 1w*3:JEPG:100,95,90
Img_targets(10001:20000,:) = 1;
Img_outputs = zeros(20000,3);

for Ji = 1:3 % ȡ��ͬJEPG��100,90,95���ı�ֵq
    if Ji == 1
        path_org_jpeg = 'G:\bossbase\OrgJPEG100\';
        path_med_jpeg = 'G:\bossbase\MedJPEG100\';
        Q = get_rate(path_org_jpeg,path_med_jpeg,B,k,l);
        %      Show_1 = show1(FM,Q);
    end
    if Ji == 2
        path_org_jpeg = 'G:\bossbase\OrgJPEG95\';
        path_med_jpeg = 'G:\bossbase\MedJPEG95\';
        Q = get_rate(path_org_jpeg,path_med_jpeg,B,k,l);
        %      Show_1 = show1(FM,Q);
    end
    if Ji == 3
        path_org_jpeg = 'G:\bossbase\OrgJPEG90\';
        path_med_jpeg = 'G:\bossbase\MedJPEG90\';
        Q = get_rate(path_org_jpeg,path_med_jpeg,B,k,l);
        %      Show_1 = show1(FM,Q);
    end
    Img_outputs(:,Ji) = Q(:); %ÿ�д�����ͬ��JPEGѹ��
    
end





figure
plotroc(Img_targets',Img_outputs')%ROC
% legend('3x3 median','JEPG=100','JEPG=90','JEPG=95');

%% 2.��ȡ���ݼ���ֺ���������
function q = get_rate(path_org_jpeg,path_med_jpeg,B,k,l)
File_type = '*jpeg';

q_org_jpeg = path_dif(path_org_jpeg,File_type,B,k,l);
q_med_jpeg = path_dif(path_med_jpeg,File_type,B,k,l);

q = [q_org_jpeg;q_med_jpeg];
end

function q = path_dif(path_d,File_type,B,k,l)
FlieList = dir([path_d,File_type]);%���벻ͬ·����JPEGͼ���ȡ��Ӧq
[FM,~] = size(FlieList);
q = zeros(FM,1);
for Fi = 1:FM
    imx = strcat(path_d,FlieList(Fi).name);
    I = double(imread(imx));
    s = size(I);
    q(Fi,1) = get_q(I,B,s,k,l);
end
end

%% 3.����ͼ������������ȡ
function q = get_q(I,B,s,k,l)
qb_hat = zeros((s(1)/B)*(s(2)/B),1);
tt = 1;
for i = 1:B:s(1) %ѭ������ͼ��������ͼ��q
    for j = 1:B:s(2)
        temp = I(i:i+B-1,j:j+B-1);
        %������
        I_d = temp(1:end-k,1:end-l)-temp(1+k:end,1+l:end);
        %0/1ֱ��ͼ��ȡ
        h0 = sum(I_d(:) == 0);
        h1 = sum(I_d(:) == 1);
        if h1 == 0
            h1 = 1;
        end
        qb = h0 / h1; %С������
        wb = 1 - (h0 / (B*B - B)); %˥������
        qb_hat(tt) = qb * wb ;
        tt = tt + 1;
    end
end
q = median(qb_hat(:));
end

function Show_1 = show1(FM,Q)
Show_1 = 1;
figure,scatter(1:FM,Q(:,1));
hold on,scatter(1:FM,Q(:,2));
xlabel('��������'),ylabel('Q���������'),legend('Org','Med')
end
