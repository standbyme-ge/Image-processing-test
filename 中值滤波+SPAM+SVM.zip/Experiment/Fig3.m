clc,clear,close all 
%figure.3  3x3 B=64 block and full
%% 1.main 
FlieList = dir('G:\bossbase\*pgm');
[FM,FN] = size(FlieList);
[k, l] = deal(0,1); %ͬʱ��ֵ
B = 64;
Img_targets = zeros(20000,2); % 2w*1:block . 2w*2:full
Img_targets(10001:20000,:) = 1; %0:1w :org . other:med
Img_outputs = zeros(20000,2);

% 1.1 block:1 and full:2        
Qqb = get_rate(FM,FlieList,B,k,l,1); %1W*1 :org qb,1W*2 :med qb
     Show1 = show1(FM,Qqb);
Qq = get_rate(FM,FlieList,B,k,l,2); %1W*1:org q,1W*2 :med q
     Show2 = show1(FM,Qq);
%����

% threshold = 0.4*(mean(Q(:,1))+mean(Q(:,2)));

Img_outputs(:,1) = Qqb(:) ; %2W*1:block -> output1
Img_outputs(:,2) = Qq(:) ; %2W*1:q:full -> output2
% Img_outputs(:,i) = double(Img_outputs(:,i) < threshold) ;


figure
plotroc(Img_targets',Img_outputs')%ROC
legend('3x3 median,B=64','block','full');

%% 2.��ȡ���ݼ���ֺ���������
function q = get_rate(FM,FlieList,B,k,l,brf)
    q = zeros(FM,2); %1W*1:org , 1W*2:med
    for Fi = 1:FM
        imx = strcat('G:\bossbase\',FlieList(Fi).name);
        I = double(imread(imx)); 
        s = size(I);
        I2 = medfilt2(I,[3,3],'symmetric');%[3x3]��ֵ�˲�����
        if brf == 1
        %2.1 block B=64
            q(Fi,1) = get_q(I,B,s,k,l,brf);%ԭͼq
            q(Fi,2) = get_q(I2,B,s,k,l,brf);%��ֵ�˲�q
        end
%         (Fi/FM)*100
        %2.2 full B=512
        if brf == 2
            q(Fi,1) = get_q(I,B,s,k,l,brf);%ԭͼq
            q(Fi,2) = get_q(I2,B,s,k,l,brf);%��ֵ�˲�q
        end

    end
end
%% 3.����ͼ������������ȡ
function q = get_q(I,B,s,k,l,brf)
    if brf == 1
        qb_hat = zeros((s(1)/B)*(s(2)/B),1);
        tt = 1;
        for i = 1:B:s(1) %ѭ������ͼ��������ͼ��q
            for j = 1:B:s(2)
                temp = I(i:i+B-1,j:j+B-1);
                %������
                I_d = temp(1:end-k,1:end-l)-temp(1+k:end,1+l:end);
                %0/1ֱ��ͼ��ȡ
                h0 = sum(I_d(:) == 0);
                h1 = sum(I_d(:) == 1);
                    if h1 == 0
                        h1 = 1;
                    end
                qb = h0 / h1; %С������
                wb = 1 - (h0 / (B*B - B)); %˥������
                qb_hat(tt) = qb * wb ;
                tt = tt + 1;
            end
        end
        q = median(qb_hat(:));
    end
    if brf == 2 %full: only q
       I_d = I(1:end-k,1:end-l)-I(1+k:end,1+l:end); 
       h0 = sum(I_d(:) == 0);
       h1 = sum(I_d(:) == 1);
            if h1 == 0
                h1 = 1;
            end
       q = h0 / h1;
    end
end

function Show_1 = show1(FM,Q)
Show_1 = 1;
figure,scatter(1:FM,Q(:,1));
hold on,scatter(1:FM,Q(:,2));
xlabel('��������'),ylabel('Q���������'),legend('Org','Med')
end
