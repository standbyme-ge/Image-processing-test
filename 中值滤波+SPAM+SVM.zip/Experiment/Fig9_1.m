clc,clear,%close all
%Fig.9���� 3x3��ֵB=64,��ͬJPEG�ȼ���100��95��90��80��70
divi=800;
FM = 1000;
T = 2;

tic
r=[];r2=[];ac=[];
for Pi = 1:3
    if Pi == 1
        path_Org_jpeg = 'G:\bossbase\OrgJPEG90\';
        path_Med_jpeg = 'G:\bossbase\MedJPEG90\';
        [result_1,ac_train,result_2,ac_test] = MainSvm(FM,T,divi,path_Org_jpeg,path_Med_jpeg);
    disp(Pi)
    end
    if Pi == 2
        path_Org_jpeg = 'G:\bossbase\OrgJPEG80\';
        path_Med_jpeg = 'G:\bossbase\MedJPEG80\';
        [result_1,ac_train,result_2,ac_test] = MainSvm(FM,T,divi,path_Org_jpeg,path_Med_jpeg);
    disp(Pi)
    end
    if Pi == 3
        path_Org_jpeg = 'G:\bossbase\OrgJPEG70\';
        path_Med_jpeg = 'G:\bossbase\MedJPEG70\';
        [result_1,ac_train,result_2,ac_test] = MainSvm(FM,T,divi,path_Org_jpeg,path_Med_jpeg);
    disp(Pi)
    end
    
    r=[r;result_1(:)'];r2=[r2;result_2(:)'];ac=[ac;ac_train(1),ac_test(1)];
end
toc
figure,plotroc(r(:,1:2*divi),r(:,2*divi+1:end),'train',r2(:,1:2*(FM-divi)),r2(:,2*(FM-divi)+1:end),'test')
% figure,
% hold on
% grid on
% plot(1:length(result_2(:,1)),result_2(:,2),'ro')
% plot(1:length(result_2(:,1)),result_2(:,1),'b+')
% legend('label','predict')
% xlabel('test-number'),ylabel('test-category')
% string={'RBF',['accuracy=',num2str(ac_test(1)),'%']};
% title(string)

%% ��������MainSvm
function [result_1,accuracy_1,result_2,accuracy_2] = MainSvm(FM,T,divi,path_Org_jpeg, path_Med_jpeg)


label=ones(FM,1);
label2=zeros(FM,1);
%JPEF-compress
matrix = Get_matrix(path_Org_jpeg,FM,T);
matrix2 = Get_matrix(path_Med_jpeg,FM,T);
% matrix =[M1;M2] ;


%}
%% SVM
%1.train

train_matrix=[matrix(1:divi,:);matrix2(1:divi,:)];

train_label=[label(1:divi,1);label2(1:divi,1)];
%2.test

test_matrix=[matrix(divi+1:end,:);matrix2(divi+1:end,:)];

test_label=[label(divi+1:end,:);label2(divi+1:end,:)];
%% ��һ��
[Train_matrix,PS]=mapminmax(train_matrix');
Train_matrix=Train_matrix';
Test_matrix=mapminmax('apply',test_matrix',PS);
Test_matrix=Test_matrix';
%%
%������֤-������c/g
[c,g]=meshgrid(-3:4,-4:4);
[m,n]=size(c);
cg=zeros(m,n);
eps=10^(-4);
v=5;
bestc=1;
bestg=0.1;
bestacc=0;
for i=1:m
    for j=1:n
        cmd=['-t 2',' -v ',num2str(v),' -c ',num2str(2^c(i,j)),' -g ',num2str(2^g(i,j)),' -h 0',' -q'];
        cg(i,j)=svmtrain(train_label,Train_matrix,cmd);
        if cg(i,j)>bestacc
            bestacc=cg(i,j);
            bestc=10^c(i,j);
            beatg=2^g(i,j);
        end
        if abs(cg(i,j)-bestacc)<=eps && bestc>2^c(i,j)
            bestacc=cg(i,j);
            bestc=2^c(i,j);
            beatg=2^g(i,j);
        end
    end
end
cmd=['-t 2',' -c ',num2str(bestc),' -g ',num2str(bestg),' -h 0'];

%2.train-svm
model=svmtrain(train_label,Train_matrix,cmd);

%% ѵ���ɹ� 
[predict_label_1,accuracy_1,decision_values1]=svmpredict(train_label,Train_matrix,model);
[predict_label_2,accuracy_2,decision_values2]=svmpredict(test_label,Test_matrix,model);
result_1=[train_label decision_values1];
result_2=[test_label decision_values2];
end

%% SPAM

function F=spam(I,T)

%% 4��ˮƽ/��ֱ����+4���ԽǾ���

%1.ˮƽ�����֣��ֱ�ȡ����������
D = I(:,1:end-1) - I(:,2:end);
L = D(:,3:end); C = D(:,2:end-1); R = D(:,1:end-2);
%M11:����M12:����
M11 = ComputerM(L,C,R,T);
M12 = ComputerM(-R,-C,-L,T);

%2.��ֱ
D = I(1:end-1,:)- I(2:end,:);
L = D(3:end,:); C = D(2:end-1,:); R = D(1:end-2,:);
M13 = ComputerM(L,C,R,T);
M14 = ComputerM(-R,-C,-L,T);

%3.��Խ�
D = I(1:end-1,1:end-1) - I(2:end,2:end);
L = D(3:end,3:end); C = D(2:end-1,2:end-1); R = D(1:end-2,1:end-2);
M21 = ComputerM(L,C,R,T);
M22 = ComputerM(-R,-C,-L,T);

%4.�ҶԽ�
D = I(2:end,1:end-1) - I(1:end-1,2:end);
L = D(1:end-2,3:end); C = D(2:end-1,2:end-1); R = D(3:end,1:end-2);
M23 = ComputerM(L,C,R,T);
M24 = ComputerM(-R,-C,-L,T);

%% ƽ������+ȡ��������F

F1 = (M11+M12+M13+M14)/4;
F2 = (M21+M22+M23+M24)/4;
F = [F1;F2];
end

function M = ComputerM(D1,D2,D3,T)

%ȥ���߽���Ԫ�ء�
D1(D1<-T)=-T; D1(D1>T)=T;
D2(D2<-T)=-T; D2(D2>T)=T;
D3(D3<-T)=-T; D3(D3>T)=T;

%��һ��
M = zeros(2*T+1,2*T+1,2*T+1);
for i=-T:T  %ͳ��-3:3��λ��
    D22 = D2(D1==i); %ͳ�Ʋ�������У��ҵ��ص�����
    D32 = D3(D1==i);
    for j=-T:T
        D33 = D32(D22==j);%ͳ���ص�������ص����֣�����ͼ�����ص�����
        for k=-T:T
            M(i+T+1,j+T+1,k+T+1) = sum(D33==k);
        end
    end
end
M = M(:)/sum(M(:));
end

function matrix = Get_matrix(path_img,FM,T)

FileList=dir([path_img,'*jpeg']);
matrix=[];
for Fi=1:FM
    imx = strcat(path_img,FileList(Fi).name);
    I2=double(imread(imx));
    F2=spam(I2,T);
    matrix=[matrix;F2'];
end

end