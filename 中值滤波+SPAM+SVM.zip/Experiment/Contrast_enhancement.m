%% �Աȶ���ǿ
I = imread('ͼƬ1.jpg'); % ����ͼ��
I(50:150,50:150,:)=imnoise(I(50:150,50:150,:),'gaussian',0.2); 
% figure,imshow(I);
% imgdata = double(img1);
% P= 1 * (imgdata .^ 1.1);
% figure,imshow(uint8(P))
% title('٤���任:c=1,��=1.1')

% g1=medfilt2(I(:,:,1));%%��
% g2=medfilt2(I(:,:,2));%%��
% g3=medfilt2(I(:,:,3));%%��
% g(:,:,1)=g1;
% g(:,:,2)=g2;
% g(:,:,3)=g3;
% imshow(g)
% title('medfilter gaussian');
% 
% 
I = rgb2gray(I);
figure,imshow(I);
I = medfilt2(I,[3,3],'symmetric');
figure,imshow(I);
title('��ֵ�˲� ')