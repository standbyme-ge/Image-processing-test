% medinan
clc,clear all
FileList = dir('C:\Users\268-yrs\Desktop\Experiment\*tif');
[FM,FN] = size(FileList);
for Fi = 1:FM
    imx = strcat('C:\Users\268-yrs\Desktop\Experiment\',FileList(Fi).name);
    I = imread(imx); 
    I = medfilt2(I,[3,3],'symmetric');
    imwrite(I,strcat('med-',FileList(Fi).name));  %�����洢

end