clc,clear,close all
%Fig.8 3x3��ֵB=64,��ͬJPEG�ȼ�
divi=1500;
path_org = 'G:\bossbase\pgm\';
    % org:pgm
    FileList=dir([path_org,'*pgm']);
    [FM,~] = size(FileList);
    %          jpeg100,90,95
    FM = 2000;
        matrix=[];
        for Fi=1:FM
        imx = strcat(path_org,FileList(Fi).name);
        I=imread(imx);%double();
        % SPAM
        F=spam(I,3);
        % �������ݾ���
        matrix=[matrix;F'];
        end
r=[];r2=[];
for Pi = 1:3
    if Pi == 1
        path_jpeg = 'G:\bossbase\JPEG90\';
        [result_1,ac_train,result_2,ac_test] = MainSvm(FM,divi,matrix,path_jpeg);
    end
    if Pi == 2
        path_jpeg = 'G:\bossbase\JPEG80\';
        [result_1,ac_train,result_2,ac_test] = MainSvm(FM,divi,matrix,path_jpeg);
    end
    if Pi == 3
        path_jpeg = 'G:\bossbase\JPEG70\';
        [result_1,ac_train,result_2,ac_test] = MainSvm(FM,divi,matrix,path_jpeg);
    end

r=[r;result_1(:)'];r2=[r2;result_2(:)'];
end 


figure,plotroc(r(:,1:3000),r(:,3001:end)),title('train')
figure,plotroc(r2(:,1:1000),r2(:,1001:end)),title('test')
% figure,
% hold on
% grid on
% plot(1:length(test_label),predict_label_2,'ro')
% plot(1:length(test_label),test_label,'b+')
% legend('label','predict')
% xlabel('test-number'),ylabel('test-category')
% string={'RBF',['accuracy=',num2str(accuracy_2(1)),'%']};
% title(string)

%% ��������MainSvm
function [result_1,accuracy_1,result_2,accuracy_2] = MainSvm(FM,divi,matrix,path_jpeg)
    FileList2=dir([path_jpeg,'*jpeg']);
    
    matrix2=[];
    label=zeros(FM,1);
    label2=ones(FM,1);

    %JPEF-compress
    
    for Fi=1:FM
        imx = strcat(path_jpeg,FileList2(Fi).name);
        I2=imread(imx);%double();
        F2=spam(I2,3);
        matrix2=[matrix2;F2'];
    end
    %}
    %% 
    %1.train
    train_matrix=matrix(1:divi,:);
    train_matrix=[train_matrix;matrix2(1:divi,:)];
    train_label=label(1:divi,1);
    train_label=[train_label;label2(1:divi,1)];
    %2.test
    test_matrix=matrix(divi+1:end,:);
    test_matrix=[test_matrix;matrix2(divi+1:end,:)];
    test_label=label(divi+1:end,:);
    test_label=[test_label;label2(divi+1:end,:)];
    %% ��һ��
    [Train_matrix,PS]=mapminmax(train_matrix');
    Train_matrix=Train_matrix';
    Test_matrix=mapminmax('apply',test_matrix',PS);
    Test_matrix=Test_matrix';
    %% 
    %������֤-������c/g
    [c,g]=meshgrid(-3:4,-4:4);
    [m,n]=size(c);
    cg=zeros(m,n);
    eps=10^(-4);
    v=5;
    bestc=1;
    bestg=0.1;
    bestacc=0;
    for i=1:m
        for j=1:n
            cmd=['-t 2',' -v ',num2str(v),' -c ',num2str(2^c(i,j)),' -g ',num2str(2^g(i,j)),' -h 0',' -q'];
            cg(i,j)=svmtrain(train_label,Train_matrix,cmd);
            if cg(i,j)>bestacc
                bestacc=cg(i,j);
                bestc=10^c(i,j);
                beatg=2^g(i,j);
            end
            if abs(cg(i,j)-bestacc)<=eps && bestc>2^c(i,j)
                bestacc=cg(i,j);
                bestc=2^c(i,j);
                beatg=2^g(i,j);
            end
        end
    end
    cmd=['-t 2',' -c ',num2str(bestc),' -g ',num2str(bestg),' -h 0',' -b 0'];

    %2.train-svm
    model=svmtrain(train_label,Train_matrix,cmd);

    %% test-svm
    %1.�鿴ѵ��Ч�� 2.�鿴����Ч��
    [predict_label_1,accuracy_1,prob_estimate_1]=svmpredict(train_label,Train_matrix,model,'-b 0');
    [predict_label_2,accuracy_2,prob_estimate_2]=svmpredict(test_label,Test_matrix,model,'-b 0');
    result_1=[train_label predict_label_1];
    result_2=[test_label predict_label_2];
end

%% SPAM 

function F=spam(I,T)

%% 4��ˮƽ/��ֱ����+4���ԽǾ���

%1.ˮƽ�����֣��ֱ�ȡ����������
D = I(:,1:end-1) - I(:,2:end);
L = D(:,3:end); C = D(:,2:end-1); R = D(:,1:end-2);
%M11:����M12:����
M11 = ComputerM(L,C,R,T);
M12 = ComputerM(-R,-C,-L,T);

%2.��ֱ
D = I(1:end-1,:)- I(2:end,:);
L = D(3:end,:); C = D(2:end-1,:); R = D(1:end-2,:);
M13 = ComputerM(L,C,R,T);
M14 = ComputerM(-R,-C,-L,T);

%3.��Խ�
D = I(1:end-1,1:end-1) - I(2:end,2:end);
L = D(3:end,3:end); C = D(2:end-1,2:end-1); R = D(1:end-2,1:end-2);
M21 = ComputerM(L,C,R,T);
M22 = ComputerM(-R,-C,-L,T);

%4.�ҶԽ�
D = I(2:end,1:end-1) - I(1:end-1,2:end);
L = D(1:end-2,3:end); C = D(2:end-1,2:end-1); R = D(3:end,1:end-2);
M23 = ComputerM(L,C,R,T);
M24 = ComputerM(-R,-C,-L,T);

%% ƽ������+ȡ��������F

F1 = (M11+M12+M13+M14)/4;
F2 = (M21+M22+M23+M24)/4;
F = [F1;F2];
end

function M = ComputerM(D1,D2,D3,T)

%ȥ���߽���Ԫ�ء�
D1(D1<-T)=-T; D1(D1>T)=T;
D2(D2<-T)=-T; D2(D2>T)=T;
D3(D3<-T)=-T; D3(D3>T)=T;

%��һ��
M = zeros(2*T+1,2*T+1,2*T+1);
for i=-T:T  %ͳ��-3:3��λ��
    D22 = D2(D1==i); %ͳ�Ʋ�������У��ҵ��ص�����
    D32 = D3(D1==i);
    for j=-T:T
       D33 = D32(D22==j);%ͳ���ص�������ص����֣�����ͼ�����ص�����
        for k=-T:T
            M(i+T+1,j+T+1,k+T+1) = sum(D33==k);
        end
    end
end
M = M(:)/sum(M(:));
end
