FlieList = dir('G:\bossbase\pgm\*pgm');
[FM,FN] = size(FlieList);
for Fi = 1:FM
   imx = strcat('G:\bossbase\pgm\',FlieList(Fi).name);
  I = imread(imx); 
  
%   I = medfilt2(I,[3,3],'symmetric');%[3x3]��ֵ�˲�����
   
   fna = strcat(num2str(Fi));
   imwrite(I,[fna '.jpeg'],'quality',70); 
%    fna1 = strcat('JpegMed95-',num2str(Fi));
%    imwrite(I,[fna1 '.jpeg'],'quality',95); 
%    fna2 = strcat('JpegMed90-',num2str(Fi));
%    imwrite(I,[fna2 '.jpeg'],'quality',90);
%    fna2 = strcat('JpegMed80-',num2str(Fi));
%    imwrite(I,[fna2 '.jpeg'],'quality',80);
%    fna2 = strcat('JpegMed70-',num2str(Fi));
%    imwrite(I,[fna2 '.jpeg'],'quality',70);
Fi/FM*100
end
